# -*- coding: utf-8 -*-
from . import medical_prescription_order
from . import medical_prescription_order_line
